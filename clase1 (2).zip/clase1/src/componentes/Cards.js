import React from 'react';



const Cards = () => (
    <div className="Cards">
        
        <h1>Productos destacados</h1>


<div class="container">
    <div class="row">
        <div class="col-md-4">
            <div class="card card-top-left">
                <div class="card-inner">
                    <img src="img/Capa-1.png" class="card-img-top" alt="..."/>
                    <h3 class="card-title">Lavatorio</h3>
                    <div class="card-body">Mueble colgante para Lavatorio.</div>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card-wrapper">
                <div class="card card-top-left">
                    <div class="card-inner">
                        <img src="img/Capa-1.png" class="card-img-top" alt="..."/>
                        <h3 class="card-title">Lavatorio</h3>
                        <div class="card-body">Mueble colgante para Lavatorio.</div>
                    </div>
                </div>
            </div>
        </div>


        <div class="col-md-4">
            <div class="card-wrapper">
                <div class="card card-top-left">
                    <div class="card-inner">
                        <img src="img/Capa-1.png" class="card-img-top" alt="..."/>
                        <h3 class="card-title">Lavatorio</h3>
                        <div class="card-body">Mueble colgante para Lavatorio.</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card-wrapper">
                <div class="card card-top-left">
                    <div class="card-inner">
                        <img src="img/Capa-1.png" class="card-img-top" alt="..."/>
                        <h3 class="card-title">Lavatorio</h3>
                        <div class="card-body">Mueble colgante para Lavatorio.</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card-wrapper">
                <div class="card card-top-left">
                    <div class="card-inner">
                        <img src="img/Capa-1.png" class="card-img-top" alt="..."/>
                        <h3 class="card-title">Lavatorio</h3>
                        <div class="card-body">Mueble colgante para Lavatorio.</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card-wrapper">
                <div class="card card-top-left">
                    <div class="card-inner">
                        <img src="img/Capa-1.png" class="card-img-top" alt="..."/>
                        <h3 class="card-title">Lavatorio</h3>
                        <div class="card-body">Mueble colgante para Lavatorio.</div>
                    </div>
                </div>
            </div>
        </div>
     


        
    </div>
</div>
        
        
        </div>
   
)
    export default Cards;