//import React from "react";
import React, { Component } from 'react';
import Header from './componentes/Header';
import Galery from './componentes/Galery';
import Cards from './componentes/Cards';
import Marcas from './componentes/Marcas';
import Footer from './componentes/Footer';
import './css/bootstrap.min.css';
import './css/styles.css';

class App extends Component {
  render() {
    return (
      <div className="App">
        <Header />    
        <Galery />  
        <Cards/>
        <Marcas/>
        <Footer/>
      </div>
    );
  }
}
export default App;